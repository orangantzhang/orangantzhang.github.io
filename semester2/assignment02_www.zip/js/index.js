document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('Device ready...');
}